<template>
  <div class="upcoming">
    <h1>
      upcoming
    </h1>
    
  </div>
</template>

<script>
export default {
  
}
</script>
<style lang="scss" scoped>
.upcoming{
 
  margin-top: 0.8rem;
}
</style>