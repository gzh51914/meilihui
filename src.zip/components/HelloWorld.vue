<template>
  <div class="hello">
    hello ziky!!
    <hr>

  </div>
</template>

<script>



export default {

}
</script>

<style lang="scss" scoped>

</style>
