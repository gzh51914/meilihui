import Vue from "vue"
import Title from "@/components/title"

//全局注册Title组件
Vue.component("Title", Title)